


#include "filter.h";


float inputs[2] = {0, 0};
float outputs[2] = {0, 0};
float w = 0;
float output = 0;



float notch(float input){

    w = numerator[0] * input + numerator[1] * inputs[1] + numerator[2] * inputs[0];
    output = w - denominator[1] * outputs[1] - denominator[2] * outputs[0];


    inputs[0] = inputs[1];
    inputs[1] = input;

    outputs[0] = outputs[1];
    outputs[1] = output;


    return output;
}


