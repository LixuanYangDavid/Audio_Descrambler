/*
 * Filter.h
 *
 *  Created on: Dec 10, 2019
 *      Author: Lixuan (David) Yang
 */

#ifndef FILTER_H_
#define FILTER_H_

#include <stdint.h>
#include <math.h>
#include <stdbool.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

// Removing 8kHz using Cheyshev Type 1 Bandstop filter
static float gain = 0.986850579878503;
static float numerator[3] = {1,-1.000342792490867882548855050117708742619,1};
static float denominator[3] = {1,-0.987188864846893499027657981059746816754, 0.973701159757005108019711769884452223778};

float notch(float input);

#endif /* SCRIPTING_FILTER_H_ */
